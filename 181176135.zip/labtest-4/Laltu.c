#define _GNU_SOURCE
#define PAGESIZE 4096
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sched.h>
#include<sys/mman.h>
#include<stdint.h>
#include "Var.h"
a = 55;
b= 43;

int main()
{
	pid_t pid, pid1, pid2;
    // scanf("%d %d", &a, &b);
    
   
	pid = fork();
	if (pid == 0) {
        execlp("/home/mayabee/Downloads/OS-Class-Practices-main/labtest-4/mittu", "mittu", NULL); 
	}

	else {
		pid1 = fork();
		if (pid1 == 0) {
            execlp("/home/mayabee/Downloads/OS-Class-Practices-main/labtest-4/ittu", "ittu", NULL); 
		}
		else {
			pid2 = fork();
			if (pid2 == 0) {
                execlp("/home/mayabee/Downloads/OS-Class-Practices-main/labtest-4/bittu", "bittu", NULL); 
			}
			else {
                printf("%d %d\n", a,b);

				printf("Parent process- pid = %u, CPU= %u\n", getpid(), sched_getcpu());
                
			}
		}
	}

	return 0;
}
