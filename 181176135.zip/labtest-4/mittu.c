#define _GNU_SOURCE
#include<stdio.h>
#include<unistd.h>
#include<sched.h>
#include "Var.h"
int main(){
    a=5;
    b=7;
    printf("Process ID %u, CPU = %u\n", getpid(), sched_getcpu());
    printf("Before Multiplication A= %d,", a);
    printf(" B = %d, ", b);
    printf( "Result = %d\n", result);

    result = result * (a * b);
    printf("Before Multiplication A= %d,", a);
    printf("B = %d,", b);
    printf( "Result = %d\n", result);
}