extern int result;
extern int a;
extern int b;
